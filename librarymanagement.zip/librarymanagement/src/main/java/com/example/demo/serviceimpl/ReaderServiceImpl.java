package com.example.demo.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.ResourceNotFound;
import com.example.demo.model.Readers;
import com.example.demo.repository.ReaderRepository;

@Service
public class ReaderServiceImpl implements Readersinterface {

    @Autowired
    private ReaderRepository readersRepository;

    @Override
    public Readers saveReader(Readers reader) {

        if (readersRepository.existsByEmail(reader.getEmail())) {
            throw new RuntimeException("EmailExists");
        }
        if (readersRepository.existsByReaderName(reader.getReaderName())) {
            throw new RuntimeException("NameExists");
        }

        return readersRepository.save(reader);
    }

    @Override
    public List<Readers> getAllReaders() {
        return readersRepository.findAll();
    }

    @Override
    public Readers getReaderByReaderId(int readerId) {
        return readersRepository.findById(readerId)
                .orElseThrow(() -> new ResourceNotFound("Readers", "readerId", readerId));
    }

    @Override
    public Readers updateReaderByReaderId(int readerId, Readers newReader) {

        Readers existingReader = getReaderByReaderId(readerId);

        existingReader.setReaderName(newReader.getReaderName());
        existingReader.setEmail(newReader.getEmail());
        existingReader.setPhoneNo(newReader.getPhoneNo());
        existingReader.setAddress(newReader.getAddress());

        return readersRepository.save(existingReader);
    }

    @Override
    public void deleteReaderById(int readerId) {
        getReaderByReaderId(readerId);
        readersRepository.deleteById(readerId);
    }

    @Override
    public List<Readers> getReaderListAfterDeleteById(int readerId) {
        getReaderByReaderId(readerId);
        return readersRepository.findAll();
    }

    // ✔ FOR LOGIN — return ONE reader
    @Override
    public Readers findReaderByName(String name) {
        return readersRepository.findByReaderName(name);
    }

    // ✔ FOR SEARCH — return list of matching readers
    @Override
    public List<Readers> searchByReaderNameContaining(String name) {
        return readersRepository.findByReaderNameContaining(name);
    }

    @Override
    public Readers findReaderByEmail(String email) {
        return readersRepository.findByEmail(email);
    }
}
