package com.example.demo.serviceimpl;

import java.util.List;
import com.example.demo.model.Report;
import com.example.demo.model.ReportResponse;

public interface Reportinterface {

    Report saveReport(Report report);

    List<Report> getAllReports();

    Report getReportByReportId(int reportId);

    Report updateReportByReportId(int reportId, Report report);

    void deleteReportById(int reportId);

    List<Report> getReportListAfterDeleteById(int reportId);

    List<Report> findReportsByReaderId(int readerId);

    List<Report> findReportsByBookId(int bookId);

    // ⭐ IMPORTANT — This returns data to Angular
    List<ReportResponse> getReaderReports();
}
