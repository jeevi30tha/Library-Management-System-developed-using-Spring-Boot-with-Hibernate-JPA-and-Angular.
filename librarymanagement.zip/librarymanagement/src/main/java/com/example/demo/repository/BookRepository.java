package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Book;

@Repository
public interface BookRepository extends JpaRepository<Book, Integer> {

    List<Book> findByBookName(String bookName);

    List<Book> findByCategoryAndAuthor(String category, String author);

    // ⭐ Get number of copies of a book
    @Query("SELECT b.copies FROM Book b WHERE b.bookId = :bookId")
    Integer findBookCopies(Integer bookId);

	List<Book> findByBookNameContainingIgnoreCase(String name);
}
