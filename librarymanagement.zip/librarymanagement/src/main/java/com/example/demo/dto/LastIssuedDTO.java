package com.example.demo.dto;

import java.time.LocalDate;

public class LastIssuedDTO {

    private String bookName;
    private String readerName;
    private LocalDate issueDate;
    private LocalDate returnDate;

    public LastIssuedDTO(String bookName, String readerName, LocalDate issueDate, LocalDate returnDate) {
        this.bookName = bookName;
        this.readerName = readerName;
        this.issueDate = issueDate;
        this.returnDate = returnDate;
    }

    public String getBookName() {
        return bookName;
    }

    public String getReaderName() {
        return readerName;
    }

    public LocalDate getIssueDate() {
        return issueDate;
    }

    public LocalDate getReturnDate() {
        return returnDate;
    }
}
