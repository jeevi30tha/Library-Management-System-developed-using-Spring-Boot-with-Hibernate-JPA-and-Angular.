package com.example.demo.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Report;
import com.example.demo.model.ReportResponse;
import com.example.demo.serviceimpl.Reportinterface;

@RestController
@RequestMapping("/report/api")
public class ReportController {

    @Autowired
    private Reportinterface reportinterface;

    @PostMapping
    public ResponseEntity<Report> saveReport(@RequestBody Report report) {
        Report saved = reportinterface.saveReport(report);
        return new ResponseEntity<>(saved, HttpStatus.CREATED);
    }

    @GetMapping
    public List<Report> getAllReports() {
        return reportinterface.getAllReports();
    }

    @GetMapping("/{reportId}")
    public Report getReport(@PathVariable int reportId) {
        return reportinterface.getReportByReportId(reportId);
    }

    @PutMapping("/{reportId}")
    public Report updateReport(@PathVariable int reportId, @RequestBody Report report) {
        return reportinterface.updateReportByReportId(reportId, report);
    }

    @DeleteMapping("/{reportId}")
    public String deleteReport(@PathVariable int reportId) {
        reportinterface.deleteReportById(reportId);
        return "Report deleted successfully";
    }

    @GetMapping("/user/{userId}")
    public List<Report> findByUserId(@PathVariable int userId) {
        return reportinterface.findReportsByReaderId(userId);
    }

    @GetMapping("/book/{bookId}")
    public List<Report> findByBookId(@PathVariable int bookId) {
        return reportinterface.findReportsByBookId(bookId);
    }

    // ⭐ NEW ENDPOINT FOR REPORT RESPONSE ⭐
    @GetMapping("/readers-report")
    public List<ReportResponse> getReaderActivityReport() {
        return reportinterface.getReaderReports();
    }
}
