package com.example.demo.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.model.AuthResponse;
import com.example.demo.model.LoginRequest;
import com.example.demo.model.Readers;
import com.example.demo.repository.ReaderRepository;

@Service
public class ReaderLoginServiceImpl {

    @Autowired
    private ReaderRepository repo;

    public AuthResponse authenticate(LoginRequest req) {

        // Check username
        Readers reader = repo.findByReaderName(req.getReaderName());

        if (reader == null) {
            return new AuthResponse(false, "Username does not exist", null);
        }

        // Check password
        if (!reader.getPassword().equals(req.getPassword())) {
            return new AuthResponse(false, "Incorrect password", null);
        }

        // Successful login
        return new AuthResponse(true, "Login Successful", reader);
    }
}


