package com.example.demo.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.AssertTrue;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="ReserveTable")
public class Reserve {

    @Id
    @GeneratedValue
    @Column(name="reserveid")
    private int reserveId;

    
    @Positive(message = "Reader ID must be a positive number")
    @Column(name="readerid")       // ✔ renamed from userid to match your Readers table
    private Integer readerId;

    @NotNull(message = "Book ID is required")
    @Positive(message = "Book ID must be a positive number")
    @Column(name="bookid")
    private Integer bookId;

   
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Column(name="reservedate")
    private LocalDate reserveDate;
   
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    @Column(name="expectedreturndate")
    private LocalDate expectedReturnDate;

    // ---------------- VALIDATIONS ------------------

    // ❗ Reserve date cannot be in the past
    @AssertTrue(message = "Reserve date cannot be a past date")
    public boolean isReserveDateValid() {
        return reserveDate == null || !reserveDate.isBefore(LocalDate.now());
    }

    // ❗ Expected return date cannot be in the past
    @AssertTrue(message = "Expected return date cannot be a past date")
    public boolean isExpectedReturnDateValid() {
        return expectedReturnDate == null || !expectedReturnDate.isBefore(LocalDate.now());
    }

    // ❗ Expected return date cannot be before reserve date
    @AssertTrue(message = "Expected return date must be after reserve date")
    public boolean isReturnDateAfterReserveDate() {
        return reserveDate == null || expectedReturnDate == null || !expectedReturnDate.isBefore(reserveDate);
    }

    // ---------------- GETTERS & SETTERS ------------------

    public int getReserveId() {
        return reserveId;
    }
    public void setReserveId(int reserveId) {
        this.reserveId = reserveId;
    }

    public Integer getReaderId() {
        return readerId;
    }
    public void setReaderId(Integer readerId) {
        this.readerId = readerId;
    }

    public Integer getBookId() {
        return bookId;
    }
    public void setBookId(Integer bookId) {
        this.bookId = bookId;
    }

    public LocalDate getReserveDate() {
        return reserveDate;
    }
    public void setReserveDate(LocalDate reserveDate) {
        this.reserveDate = reserveDate;
    }

    public LocalDate getExpectedReturnDate() {
        return expectedReturnDate;
    }
    public void setExpectedReturnDate(LocalDate expectedReturnDate) {
        this.expectedReturnDate = expectedReturnDate;
    }

    @Override
    public String toString() {
        return "Reserve [reserveId=" + reserveId +
                ", readerId=" + readerId +
                ", bookId=" + bookId +
                ", reserveDate=" + reserveDate +
                ", expectedReturnDate=" + expectedReturnDate + "]";
    }
}
