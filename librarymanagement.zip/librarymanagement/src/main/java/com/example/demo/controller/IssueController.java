package com.example.demo.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dto.LastIssuedDTO;

import com.example.demo.model.Issue;
import com.example.demo.repository.IssueRepository;
import com.example.demo.serviceimpl.Issueinterface;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/issue/api")
@CrossOrigin(origins = "http://localhost:4200")
public class IssueController {

    @Autowired
    private Issueinterface issueService;

    @Autowired
    private IssueRepository issueRepository;

    // ================= BASIC ENDPOINTS =================

    @GetMapping
    public List<Issue> getAllIssues() {
        return issueService.getAllIssues();
    }

    @GetMapping("/id/{issueId}")
    public Issue getIssueByIssueId(@PathVariable int issueId) {
        return issueService.getIssueByIssueId(issueId);
    }

    @PutMapping("/id/{issueId}")
    public Issue updateIssueByIssueId(@PathVariable int issueId, @RequestBody Issue issue) {
        return issueService.updateIssueByIssueId(issueId, issue);
    }

    @DeleteMapping("/id/{issueId}")
    public String deleteIssueByIssueId(@PathVariable int issueId) {
        issueService.deleteIssueById(issueId);
        return "Issue deleted successfully " + issueId;
    }

    // ================= READER =================

    @GetMapping("/reader/{readerId}")
    public List<Issue> getIssuedBooksByReader(@PathVariable int readerId) {
        return issueService.getIssuedBooksForReader(readerId);
    }

    @GetMapping("/reader/{readerId}/issued")
    public List<Issue> getOnlyIssuedBooks(@PathVariable int readerId) {
        return issueService.getIssuedBooksOnly(readerId);
    }

    // ================= RETURN BOOK =================

    @PutMapping("/return/{issueId}")
    public ResponseEntity<String> returnBook(@PathVariable int issueId) {
        Issue issue = issueRepository.findById(issueId).orElse(null);

        if (issue == null) {
            return ResponseEntity.status(404).body("Issue record not found");
        }

        issue.setStatus("RETURNED");
        issue.setActualReturnDate(LocalDate.now());
        issueRepository.save(issue);

        return ResponseEntity.ok("Book returned successfully");
    }

    // ================= REPORTS =================

   
    @GetMapping("/last")
    public List<LastIssuedDTO> getLastIssuedBooks() {
        return issueService.getLastIssued();
    }

    @GetMapping("/today")
    public List<Issue> getTodayIssuedBooks() {
        return issueService.getTodayIssued();
    }

    @GetMapping("/overdue")
    public List<Issue> getOverdueBooks() {
        return issueService.getOverdueIssues();
    }

    // ================= CREATE ISSUE =================

    @PostMapping
    public ResponseEntity<?> saveIssue(@Valid @RequestBody Issue issue) {

        Issue existing = issueRepository.findActiveIssuedBook(
                issue.getReaderId(),
                issue.getBookId()
        );

        if (existing != null) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("This book is already issued to this reader!");
        }

        int issuedCount = issueRepository.countIssuedCopies(issue.getBookId());
        Integer totalCopies = issueRepository.findBookCopies(issue.getBookId());

        if (totalCopies == null) totalCopies = 1;

        if (issuedCount >= totalCopies) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("All copies of this book are already issued!");
        }

        if (issue.getReturnDate().isBefore(issue.getIssueDate())) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body("Return date cannot be before issue date!");
        }

        issue.setStatus("ISSUED");
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(issueService.saveIssue(issue));
    }
}
