package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Reserve;
import com.example.demo.serviceimpl.Reserveinterface;

@RestController
@RequestMapping("/reserve/api")
@CrossOrigin(origins = "http://localhost:4200")
public class ReserveController {

    @Autowired
    private Reserveinterface reserveinterface;

    // ✅ CREATE reservation (WITH DUPLICATE CHECK)
    @PostMapping
    public ResponseEntity<?> saveReserve(@RequestBody Reserve reserve) {
        try {
            reserveinterface.saveReserve(reserve);
            return ResponseEntity.ok("Book reserved successfully");
        } catch (DataIntegrityViolationException ex) {
            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body("You have already reserved this book");
        }
    }



    // GET all reservations
    @GetMapping
    public List<Reserve> getAllReserves() {
        return reserveinterface.getAllReserves();
    }

    // GET reservation by ID
    @GetMapping("/{reserveId}")
    public Reserve getReserveByReserveId(@PathVariable int reserveId) {
        return reserveinterface.getReserveByReserveId(reserveId);
    }

    // UPDATE reservation
    @PutMapping("/{reserveId}")
    public Reserve updateReserveByReserveId(
            @PathVariable int reserveId,
            @RequestBody Reserve reserve) {
        return reserveinterface.updateReserveByReserveId(reserveId, reserve);
    }

    // DELETE reservation
    @DeleteMapping("/{reserveId}")
    public String deleteReserveByReserveId(@PathVariable int reserveId) {
        reserveinterface.deleteReserveById(reserveId);
        return "Reservation deleted successfully " + reserveId;
    }

    // FIND reservations by READER ID
    @GetMapping("/findbyreaderid/{readerId}")
    public List<Reserve> findReserveByReaderId(@PathVariable int readerId) {
        return reserveinterface.findReserveByUserId(readerId);
    }

    // FIND reservations by BOOK ID
    @GetMapping("/findbybookid/{bookId}")
    public List<Reserve> findReserveByBookId(@PathVariable int bookId) {
        return reserveinterface.findReserveByBookId(bookId);
    }
}
