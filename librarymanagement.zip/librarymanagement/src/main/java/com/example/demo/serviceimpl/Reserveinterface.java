package com.example.demo.serviceimpl;

import java.util.List;

import com.example.demo.model.Reserve;

public interface Reserveinterface {

    public Reserve saveReserve(Reserve reserve);

    public List<Reserve> getAllReserves();

    public Reserve getReserveByReserveId(int reserveId);

    public Reserve updateReserveByReserveId(int reserveId, Reserve reserve);

    public void deleteReserveById(int reserveId);

    public List<Reserve> getReserveListAfterDeleteById(int reserveId);

    // custom finder methods
    public List<Reserve> findReserveByUserId(int userId);

    public List<Reserve> findReserveByBookId(int bookId);
}
