import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Services } from '../../service/services';

@Component({
  selector: 'app-readerregister',
  standalone:false,
  templateUrl: './readerregister.html',
  styleUrls: ['./readerregister.css'],
})
export class Readerregister {

  reader = {
    readerName: '',
    email: '',
    phoneNo: '',
    address: '',
    password: '',
    dateOfBirth: '',
    role:'READER'
  };

  constructor(private router: Router, private service: Services) {}

  registerReader() {

    console.log("Register button clicked");

    
     //Empty Validation
    
    if (
      !this.reader.readerName ||
      !this.reader.email ||
      !this.reader.phoneNo ||
      !this.reader.address ||
      !this.reader.password ||
      !this.reader.dateOfBirth||
      !this.reader.role
    ) {
      alert("⚠ All fields are required!");
      return;
    }

    //email 
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/;
    if (!emailPattern.test(this.reader.email)) {
      alert("⚠ Enter a valid email!");
      return;
    }

    
    // 3️ Phone Number Validation
    

    // (a) must be 10 digits
    if (this.reader.phoneNo.length !== 10) {
      alert("⚠ Phone number must be exactly 10 digits!");
      return;
    }

    // (b) must start with 6–9
    const phonePattern = /^[6-9][0-9]{9}$/;
    if (!phonePattern.test(this.reader.phoneNo)) {
      alert("⚠ Phone number must start with 6/7/8/9!");
      return;
    }

   
   
    //  API Call
    
    this.service.registerReader(this.reader).subscribe({
      next: () => {
        alert(" Registered Successfully!");

        // Reset form
        this.reader = {
          readerName: '',
          email: '',
          phoneNo: '',
          address: '',
          password: '',
          dateOfBirth: '',
          role:'READER'
        };
      },
      error: (err) => {
  if (err.status === 409) {
    alert("⚠ Email already exists!");
  } else if (err.status === 410) {
    alert("⚠ Reader name already exists!");
  }
  else {
    alert("❌ Registration failed. Try again!");
  }
      }
    });
  }
}
