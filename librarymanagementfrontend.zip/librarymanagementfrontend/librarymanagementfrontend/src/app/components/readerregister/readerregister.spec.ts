import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Readerregister } from './readerregister';

describe('Readerregister', () => {
  let component: Readerregister;
  let fixture: ComponentFixture<Readerregister>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Readerregister]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Readerregister);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
