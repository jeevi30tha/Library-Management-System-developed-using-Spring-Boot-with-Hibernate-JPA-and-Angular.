import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Deletebook } from './deletebook';

describe('Deletebook', () => {
  let component: Deletebook;
  let fixture: ComponentFixture<Deletebook>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [Deletebook]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Deletebook);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
