import { Component, ChangeDetectorRef } from '@angular/core';
import { Services } from '../../service/services';

@Component({
  selector: 'app-updatebook',
  standalone: false,
  templateUrl: './updatebook.html',
  styleUrls: ['./updatebook.css']
})
export class Updatebook {

  bookName: string = '';
  book: any = {};
  bookFound = false;

  errorMessage = '';
  successMessage = '';

  suggestions: string[] = [];
  allBooks: any[] = [];

  constructor(
    private service: Services,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit() {
    this.service.getAllBooks().subscribe(data => {
      this.allBooks = data;
    });
  }

  /* 🔍 SEARCH BY BOOK NAME */
  searchBookByName() {
    this.errorMessage = '';
    this.successMessage = '';
    this.bookFound = false;

    if (!this.bookName.trim()) {
      this.errorMessage = 'Please enter book name';
      return;
    }

    this.service.getAllBooks().subscribe({
      next: (books: any[]) => {
        const found = books.find(
          b => b.bookName?.toLowerCase() === this.bookName.trim().toLowerCase()
        );

        if (found) {
          this.book = { ...found };
          this.bookFound = true;
          this.cd.detectChanges();
        } else {
          this.errorMessage = 'Book not found';
        }
      },
      error: () => {
        this.errorMessage = 'Failed to fetch books';
      }
    });
  }

  /* ✏️ UPDATE BOOK */
  updateBook() {
    if (!this.bookFound || !this.book.bookId) {
      this.errorMessage = 'Search book first';
      return;
    }

    this.service.updateBook(this.book.bookId, this.book).subscribe({
      next: () => {
        this.successMessage = 'Book updated successfully!';
        this.errorMessage = '';

        // ✅ RESET FOR NEXT BOOK
        this.resetForm();
      },
      error: () => {
        this.errorMessage = 'Update failed';
      }
    });
  }

  /* 🔁 RESET FORM */
  resetForm() {
    this.bookName = '';
    this.book = {};
    this.bookFound = false;
    this.suggestions = [];

    this.cd.detectChanges();
  }

  /* 🔍 SUGGESTIONS WHILE TYPING */
  onType() {
    const text = this.bookName.toLowerCase().trim();

    if (!text) {
      this.suggestions = [];
      return;
    }

    this.suggestions = this.allBooks
      .map(b => b.bookName)
      .filter(name => name.toLowerCase().includes(text))
      .slice(0, 5);
  }

  /* ✅ CLICK SUGGESTION */
  selectSuggestion(name: string) {
    this.bookName = name;
    this.suggestions = [];
    this.searchBookByName();
  }

  /* 🧹 HIDE SUGGESTIONS */
  hideSuggestions() {
    setTimeout(() => (this.suggestions = []), 200);
  }
}
