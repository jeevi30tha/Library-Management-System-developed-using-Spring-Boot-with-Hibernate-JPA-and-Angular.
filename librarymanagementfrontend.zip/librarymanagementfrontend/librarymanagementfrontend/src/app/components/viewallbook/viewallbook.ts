import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Services } from '../../service/services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-viewallbook',
  standalone: false,
  templateUrl: './viewallbook.html',
  styleUrls: ['./viewallbook.css']
})
export class Viewallbook implements OnInit {

  books: any[] = [];
  allBooks: any[] = [];
  filteredBooks: any[] = [];

  searchText: string = '';
  loading: boolean = false;
  error: string = '';

  selectedCategory: string = 'All';

  constructor(
    private service: Services,
    private router: Router,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.loadBooks();
  }

  loadBooks() {
    this.loading = true;

    this.service.getAllBooks().subscribe({
      next: (data) => {
        this.allBooks = data;        // ✅ FIX
        this.books = data;
        this.filteredBooks = data;
        this.loading = false;
        this.cd.detectChanges();
      },
      error: () => {
        this.error = 'Failed to load books';
        this.loading = false;
      }
    });
  }

  search() {
    const t = this.searchText.trim().toLowerCase();

    this.filteredBooks = this.allBooks.filter(b =>
      b.bookName?.toLowerCase().includes(t) ||
      b.author?.toLowerCase().includes(t) ||
      b.category?.toLowerCase().includes(t)
    );
  }

  applyCategoryFilter(category: string) {
    this.selectedCategory = category;

    if (category === 'All') {
      this.filteredBooks = this.allBooks;
    } else {
      this.filteredBooks = this.allBooks.filter(
        book => book.category?.toLowerCase() === category.toLowerCase()
      );
    }
  }

  goToUpdate(bookId: number) {
    this.router.navigate(['/updatebook'], {
      queryParams: { id: bookId }
    });
  }
}
