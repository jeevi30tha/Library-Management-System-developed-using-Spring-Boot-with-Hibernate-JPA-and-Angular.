import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'app-managebook',
  standalone:false,
  templateUrl: './managebook.html',
  styleUrls: ['./managebook.css'],
  encapsulation: ViewEncapsulation.None
})
export class Managebook {

}
