import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { Services } from '../../service/services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-readerhomepage',
  standalone: false,
  templateUrl: './readerhomepage.html',
  styleUrls: ['./readerhomepage.css']
})
export class Readerhomepage implements OnInit {

  readerName = '';
  readerId!: number;

  menuOpen = false;
  view: 'recommended' | 'reserved' | 'issued' = 'recommended';

  allBooks: any[] = [];
  reservedBooks: any[] = [];
  issuedBooks: any[] = [];

  /* 🔹 CATEGORY */
  selectedCategory: string = 'All';
  filteredBooksByCategory: any[] = [];

  /* 🔍 SEARCH */
  searchText = '';
  filteredSuggestions: any[] = [];
  showSuggestions = false;

  constructor(
    private service: Services,
    private router: Router,
    private cd: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.readerId = Number(localStorage.getItem('readerId'));
    this.readerName = localStorage.getItem('readerName') || 'Reader';

    this.loadAllBooks();
  }

  /* ================= MENU ================= */
  toggleMenu() {
    this.menuOpen = !this.menuOpen;
  }

  logout() {
    localStorage.clear();
    this.router.navigate(['/login'], { replaceUrl: true });
  }

  goToUpdatePassword() {
    this.router.navigate(['/update-password']);
  }

  /* ================= LOAD BOOKS ================= */
  loadAllBooks() {
    this.service.getAllBooks().subscribe({
      next: books => {
        this.allBooks = books;
        this.applyCategoryFilter('All');
        this.loadReservedBooks();
        this.loadIssuedBooks();
        this.cd.detectChanges();
      },
      error: () => {
        this.allBooks = [];
        this.filteredBooksByCategory = [];
      }
    });
  }

  loadReservedBooks() {
    this.service.getReservationsByReader(this.readerId).subscribe({
      next: res => {
        this.reservedBooks = res.map(r => {
          const book = this.allBooks.find(b => b.bookId === r.bookId);
          return {
            ...r,
            bookName: book?.bookName,
            image_url: book?.imageUrl
          };
        });
        this.cd.detectChanges();
      }
    });
  }

  /*  ONLY ISSUED BOOKS */
  loadIssuedBooks() {
  this.service.getOnlyIssuedBooks(this.readerId).subscribe({
    next: (issued: any[]) => {
      this.issuedBooks = issued.map(i => {
        const book = this.allBooks.find(b => b.bookId === i.bookId);
        return {
          ...i,
          bookName: book?.bookName,
          imageUrl: book?.imageUrl
        };
      });
    },
    error: () => this.issuedBooks = []
  });
}


  /* ================= CATEGORY FILTER ================= */
  applyCategoryFilter(category: string) {
    this.selectedCategory = category;

    if (category === 'All') {
      this.filteredBooksByCategory = [...this.allBooks];
    } else {
      this.filteredBooksByCategory = this.allBooks.filter(
        b => b.category?.toLowerCase() === category.toLowerCase()
      );
    }
  }

  /* ================= SEARCH ================= */
  onSearchChange() {
    if (!this.searchText.trim()) {
      this.showSuggestions = false;
      this.applyCategoryFilter(this.selectedCategory);
      return;
    }

    this.filteredSuggestions = this.allBooks.filter(book =>
      book.bookName.toLowerCase().includes(this.searchText.toLowerCase())
    );

    this.showSuggestions = this.filteredSuggestions.length > 0;
  }

  selectSuggestion(bookName: string) {
    this.searchText = bookName;
    this.showSuggestions = false;

    this.filteredBooksByCategory = this.allBooks.filter(
      b => b.bookName === bookName
    );
  }

  clearSearch() {
    this.searchText = '';
    this.showSuggestions = false;
    this.applyCategoryFilter(this.selectedCategory);
  }

  /* ================= ACTION ================= */
  reserveBook(bookId: number) {
    this.router.navigate(['/reservebook'], {
      queryParams: { bookId }
    });
  }
}
