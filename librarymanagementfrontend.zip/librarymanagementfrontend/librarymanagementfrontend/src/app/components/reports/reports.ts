import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Services } from '../../service/services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-reports',
  standalone: false,
  templateUrl: './reports.html',
  styleUrls: ['./reports.css']
})
export class Reports implements OnInit {

  reports: any[] = [];
  loading = true;

  constructor(private service: Services, private router: Router,private cd:ChangeDetectorRef) {
    console.log("Reports Component Loaded ✔");
  }

  ngOnInit(): void {
    this.service.getReaderReports().subscribe({
      next: (response) => {
        console.log("Report Response:", response);
        this.reports = response;   // Store data
        this.loading=false;
        this.cd.detectChanges();
       
      },
      error: (err) => {
        console.error("Report Error:", err);
        this.loading = false;
      }
    });
  }

  goBack() {
    this.router.navigate(['/librarianhomepage']);
  }
}
