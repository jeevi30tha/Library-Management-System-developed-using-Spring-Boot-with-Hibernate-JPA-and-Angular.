import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Services } from '../../service/services';

@Component({
  selector: 'app-librarianhomepage',
  standalone: false,
  templateUrl: './librarianhomepage.html',
  styleUrls: ['./librarianhomepage.css'],
  
})
export class Librarianhomepage implements OnInit {

  totalBooks = 0;
  issuedToday = 0;
  overdueBooks = 0;
  totalReaders = 0;

  lastIssued: any[] = [];

  librarianName: string = "";
  menuOpen = false;

  constructor(private service: Services, private router: Router,private cd:ChangeDetectorRef) {}

  ngOnInit() {
    // librarianName saved in localStorage when user logs in
    this.cd.detectChanges();
    this.librarianName = localStorage.getItem("librarianName") || "Librarian";

    this.loadDashboardCounts();
    
  }

  toggleMenu() {
    this.cd.detectChanges();
    this.menuOpen = !this.menuOpen;
  }

  logout() {
    localStorage.removeItem('librarianName');
    localStorage.removeItem('token'); // if you use token
    this.router.navigate(['/login']);
  }

  loadDashboardCounts() {
    // Total books
    
    this.service.getAllBooks().subscribe({
      next: (res: any) => {
        this.totalBooks = Array.isArray(res) ? res.length : Number(res) || 0;
        this.cd.detectChanges();
      },
      error: err => {
        console.error('getAllBooks error', err);
        this.totalBooks = 0;
      }
    });

    // Total readers
   
    this.service.getAllReaders().subscribe({
      next: (res: any) => {
        this.totalReaders = Array.isArray(res) ? res.length : Number(res) || 0;
         this.cd.detectChanges();
      },
      error: err => {
        console.error('getAllReaders error', err);
        this.totalReaders = 0;
      }
    });

    // Recently issued books
   
    this.service.getLastIssuedBooks().subscribe({
      next: (res: any) => {
        this.lastIssued = Array.isArray(res) ? res : [];
         this.cd.detectChanges();


      },
      error: err => {
        console.error('getLastIssuedBooks error', err);
        this.lastIssued = [];
      }
    });

    // Books issued today (backend may return array or a number)
   
    this.service.getIssuedToday().subscribe({
      next: (res: any) => {
        this.issuedToday = Array.isArray(res) ? res.length : Number(res) || 0;
         this.cd.detectChanges();
      },
      error: err => {
        console.error('getIssuedToday error', err);
        this.issuedToday = 0;
      }
    });

    // Overdue books (backend may return array or a number)
    this.service.getOverdueBooks().subscribe({
      next: (res: any) => {
        this.overdueBooks = Array.isArray(res) ? res.length : Number(res) || 0;
      },
      error: err => {
        console.error('getOverdueBooks error', err);
        this.overdueBooks = 0;
      }
    });
  }

  // --- Change password flow (simple prompt UI) ---
  onClickChangePassword() {
    // close menu
    this.menuOpen = false;

    // basic browser prompt flow (replace with proper modal if you prefer)
    const oldPassword = prompt('Enter your current password:');
    if (!oldPassword) return;

    const newPassword = prompt('Enter new password:');
    if (!newPassword) return;

    const confirm = prompt('Confirm new password:');
    if (newPassword !== confirm) {
      alert('New passwords do not match.');
      return;
    }

    // get logged-in librarian id (you need to store id during login)
    const idStr = localStorage.getItem('librarianId');
    if (!idStr) {
      alert('No librarian id found. You must be logged in.');
      return;
    }
    const id = Number(idStr);

    const payload = { oldPassword, newPassword };

    this.service.updatePassword(id, payload).subscribe({
      next: (res: any) => {
        alert(typeof res === 'string' ? res : 'Password updated successfully.');
      },
      error: (err) => {
        console.error('updatePassword error', err);
        const message = err?.error || 'Failed to update password';
        alert(message);
      }
    });
  }

}
