import { Component } from '@angular/core';

@Component({
  selector: 'app-welcome',
  standalone:false,
  templateUrl: './welcome.html',
  styleUrls: ['./welcome.css']

})
export class Welcome {

}
