import { Component, OnInit } from '@angular/core';
import { Services } from '../../service/services';

@Component({
  selector: 'app-searchbook',
  standalone: false,
  templateUrl: './searchbook.html',
  styleUrls: ['./searchbook.css']
})
export class Searchbook implements OnInit {

  name: string = '';
  books: any[] = [];
  allBooks: any[] = [];
  suggestions: string[] = [];
  error: string = '';

  constructor(private service: Services) {}

  ngOnInit(): void {
    // Load all books once (for suggestions)
    this.service.getAllBooks().subscribe({
      next: (data) => {
        this.allBooks = data;
      },
      error: () => {
        this.error = 'Failed to load books';
      }
    });
  }

  // 🔍 Google-like suggestion while typing
  onType(): void {
    const text = this.name.toLowerCase().trim();

    if (!text) {
      this.suggestions = [];
      return;
    }

    this.suggestions = this.allBooks
      .map(b => b.bookName)
      .filter(name => name.toLowerCase().includes(text))
      .slice(0, 5);
  }

  // ✅ Click suggestion
  selectSuggestion(value: string): void {
    this.name = value;
    this.suggestions = [];
    this.search();
  }

  // 🔎 Actual search
  search(): void {
    const text = this.name.toLowerCase().trim();

    if (!text) {
      this.books = [];
      return;
    }

    this.books = this.allBooks.filter(b =>
      b.bookName.toLowerCase().includes(text)
    );

    //  CLEAR search box after search
  this.name = '';
  this.suggestions = [];
  }

  hideSuggestions(): void {
    setTimeout(() => {
      this.suggestions = [];
    }, 200);
  }

  
}
