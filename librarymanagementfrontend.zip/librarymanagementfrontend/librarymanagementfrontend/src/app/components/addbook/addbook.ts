import { Component, ViewEncapsulation, ViewChild, ElementRef } from '@angular/core';
import { Services } from '../../service/services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addbook',
  standalone: false,
  templateUrl: './addbook.html',
  styleUrls: ['./addbook.css'],
  encapsulation: ViewEncapsulation.None
})
export class Addbook {

  @ViewChild('fileInput') fileInput!: ElementRef;

  book = {
    bookName: '',
    author: '',
    category: '',
    imageUrl: '',
    publisherName: '',
    publishYear: ''
  };

  selectedFile: File | null = null;
  preview: string | ArrayBuffer | null = null;

  constructor(private service: Services, private router: Router) {}

  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];

    if (!this.selectedFile) return;

    const reader = new FileReader();
    reader.onload = () => {
      this.preview = reader.result;
    };
    reader.readAsDataURL(this.selectedFile);
  }

  addBook() {
    if (!this.selectedFile) {
      alert("Please choose an image");
      return;
    }

    const formData = new FormData();
    formData.append("file", this.selectedFile);

    this.service.uploadImage(formData).subscribe({
      next: (res: any) => {
        this.book.imageUrl = res.imageUrl;

        this.service.addBook(this.book).subscribe({
          next: () => {
            alert("Book added successfully!");
            this.resetForm();   // RESET EVERYTHING
          },
          error: () => alert("Failed to save book")
        });
      },
      error: () => alert("Image upload failed")
    });
  }

  resetForm() {
    // reset object
    this.book = {
      bookName: '',
      author: '',
      category: '',
      imageUrl: '',
      publisherName: '',
      publishYear: ''
    };

    // reset image preview
    this.preview = null;

    // reset file
    this.selectedFile = null;

    //  CLEAR FILE INPUT
    if (this.fileInput) {
      this.fileInput.nativeElement.value = '';
    }
  }

  goBack() {
    this.router.navigate(['/managebook']);
  }
}
