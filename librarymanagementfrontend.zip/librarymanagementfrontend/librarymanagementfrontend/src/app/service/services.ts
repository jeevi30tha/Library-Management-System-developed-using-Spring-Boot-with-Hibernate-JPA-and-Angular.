import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class Services {

  private readerUrl = 'http://localhost:8080/reader/api';
  private bookUrl = 'http://localhost:8080/book/api';
  private issueUrl = 'http://localhost:8080/issue/api';

  constructor(private http: HttpClient) {}

  /* ================= ISSUE ================= */

  // ✅ ONLY ISSUED BOOKS (READER)
  getOnlyIssuedBooks(readerId: number): Observable<any[]> {
    return this.http.get<any[]>(
      `${this.issueUrl}/reader/${readerId}/issued`
    );
  }

  getIssuedBooks(readerId: number): Observable<any[]> {
    return this.http.get<any[]>(`${this.issueUrl}/reader/${readerId}`);
  }

  issueBook(data: any): Observable<any> {
    return this.http.post(this.issueUrl, data);
  }

  returnBook(issueId: number): Observable<any> {
    return this.http.put(
      `${this.issueUrl}/return/${issueId}`,
      {},
      { responseType: 'text' }
    );
  }

  getLastIssuedBooks(): Observable<any[]> {
    return this.http.get<any[]>(`${this.issueUrl}/last`);
  }

  getIssuedToday(): Observable<any> {
    return this.http.get(`${this.issueUrl}/today`);
  }

  getOverdueBooks(): Observable<any> {
    return this.http.get(`${this.issueUrl}/overdue`);
  }

  /* ================= RESERVATION ================= */

  reserveBook(data: any) {
    return this.http.post(`http://localhost:8080/reserve/api`, data);
  }

  getReservationsByReader(readerId: number): Observable<any[]> {
    return this.http.get<any[]>(
      `http://localhost:8080/reserve/api/findbyreaderid/${readerId}`
    );
  }

  cancelReservation(reserveId: number): Observable<any> {
    return this.http.delete(
      `http://localhost:8080/reserve/api/${reserveId}`
    );
  }

  /* ================= BOOK ================= */

  uploadImage(formData: FormData) {
    return this.http.post(`${this.bookUrl}/upload`, formData);
  }

  getAllBooks(): Observable<any[]> {
    return this.http.get<any[]>(this.bookUrl);
  }

  getBookById(bookId: number): Observable<any> {
    return this.http.get(`${this.bookUrl}/${bookId}`);
  }

  addBook(book: any): Observable<any> {
    return this.http.post(this.bookUrl, book);
  }

  updateBook(bookId: number, book: any): Observable<any> {
    return this.http.put(`${this.bookUrl}/${bookId}`, book);
  }

  deleteBook(bookId: number): Observable<any> {
    return this.http.delete(`${this.bookUrl}/${bookId}`, {
      responseType: 'text'
    });
  }

  findByBookName(name: string): Observable<any[]> {
    return this.http.get<any[]>(
      `${this.bookUrl}/findbybookname/${name}`
    );
  }

  findByCategoryAndAuthor(category: string, author: string): Observable<any[]> {
    return this.http.get<any[]>(
      `${this.bookUrl}/findbycategoryandauthor/${category}/${author}`
    );
  }

  /* ================= READER ================= */

  getAllReaders(): Observable<any[]> {
    return this.http.get<any[]>(`${this.readerUrl}/readers-only`);
  }

  registerReader(reader: any): Observable<any> {
    return this.http.post(this.readerUrl, reader);
  }

  loginReader(data: any) {
    return this.http.post(`${this.readerUrl}/login`, data);
  }

  updatePassword(id: number, body: any) {
    return this.http.put(
      `${this.readerUrl}/update-password/${id}`,
      body,
      { responseType: 'text' }
    );
  }

  getReaderDashboard(readerId: number): Observable<any> {
    return this.http.get(`${this.readerUrl}/dashboard/${readerId}`);
  }

  /* ================= REPORT ================= */

  getReaderReports(): Observable<any[]> {
    return this.http.get<any[]>(
      `http://localhost:8080/report/api/readers-report`
    );
  }

  /* ================= SEARCH ================= */

  getBookSuggestions(query: string): Observable<any[]> {
    return this.http.get<any[]>(`${this.bookUrl}/search/${query}`);
  }
}
